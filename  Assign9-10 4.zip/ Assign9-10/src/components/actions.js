// actions.js
export const logout = () => ({
    type: 'user/logout',
  });
  